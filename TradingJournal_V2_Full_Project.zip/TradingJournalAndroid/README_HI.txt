TRADING JOURNAL V2.0 — OFFLINE ANDROID APP
==========================================

V2.0 में शामिल:
- Dashboard: Net P&L, Win Rate, Profit Factor, Average R, Expectancy
- Trade Entry: Market, Symbol, Strategy, timeframe, session, HTF bias, setup
- Single entry confirmation + multi-select confirmations और indicators
- BUY/SELL, Open/Closed status, manual entry और manual final exit
- Fixed price, ATR-based और Risk:Reward based SL/TP calculations
- Symbol-wise Point Value profiles (एक बार save, आगे auto-fill)
- MAE/MFE, fees, risk amount और Net R calculation
- Psychology, rule adherence, mistake tags, notes और compressed chart screenshot
- Saved Strategy Presets
- In-app editable dropdown options
- Daily/Weekly/Monthly profit targets और maximum loss limits
- Maximum trades per day और consecutive loss warnings
- Limit warning के बाद भी trade save करने की सुविधा; optional breach reason
- Equity curve, maximum drawdown, win/loss streaks
- Strategy, setup, session, hour, weekday, timeframe, BUY/SELL, emotion और rule analysis
- Daily, Weekly, Monthly और Yearly reports; monthly P&L calendar
- Automatic performance coach: strengths, review areas और per-trade feedback
- JSON backup/restore और CSV export
- Offline storage; कोई broker connection या live price feed नहीं

ACCOUNTING RULES
----------------
Long Gross P&L = (Exit - Entry) x Quantity x Point Value
Short Gross P&L = (Entry - Exit) x Quantity x Point Value
Net P&L = Gross P&L - Total Fees
Initial Risk = |Entry - Initial SL| x Quantity x Point Value
Net R = Net P&L / Initial Risk

Point Value का अर्थ: एक price point के move पर एक quantity/lot का INR value.
इसे हर symbol/contract के लिए broker specification के अनुसार verify करें।
गलत Point Value से P&L, Risk और R-Multiple गलत होंगे।

DATA SAFETY
-----------
- Data इस Android app के WebView local storage में रहता है।
- App uninstall या app data clear होने पर local data हट सकता है।
- नियमित JSON backup लें। Backup Downloads/TradingJournal में सेव होता है।
- पुराने V1/V1.1 journal से JSON backup लेकर V2.0 के Settings > Backup/Restore में import करें।
- Import default रूप से नए Trade IDs merge करता है। Replace option current data overwrite कर सकता है।

BUILD APK USING GITHUB FROM MOBILE
---------------------------------
इस ZIP में TradingJournalAndroid folder के अंदर Android project है।
GitHub repository में root पर ZIP upload करके existing build-from-zip.yml को इस तरह update करें:

1. ZIP filename: TradingJournal_V2_Full_Project.zip
2. Workflow की Extract line:
   unzip -q TradingJournal_V2_Full_Project.zip -d extracted
3. उसके बाद पहले से मौजूद copy line रखें:
   cp -R extracted/TradingJournalAndroid/. .
4. Workflow में Gradle build command रखें:
   gradle --no-daemon clean assembleDebug
5. Commit changes करें। Actions > Build Trading Journal APK > Run workflow.
6. Workflow artifact TradingJournal-V2.0-APK डाउनलोड करें और ZIP Extract करके app-debug.apk install करें।

महत्वपूर्ण: Repository में project folder के अंदर की files root पर copy होंगी; ZIP को केवल upload करने से GitHub खुद extract नहीं करता।

ANDROID PACKAGE / VERSION
-------------------------
Application ID: com.tradingjournal.offline
Version Name: 2.0
Version Code: 4
Min Android API: 29 (Android 10)
Target SDK: 35

DEBUG APK SIGNATURE NOTE
------------------------
GitHub Actions में बना debug APK नए runner पर अलग debug-signing key से sign हो सकता है।
इसलिए पुराने APK के ऊपर सीधे update install न हो तो पहले पुरानी app से JSON backup लें, पुराने app को uninstall करें, V2 install करें, फिर JSON restore करें।
